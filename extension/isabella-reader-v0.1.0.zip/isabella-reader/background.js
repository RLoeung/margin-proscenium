const READ_MENU_ID = "isabella-read-selection";
const STOP_MENU_ID = "isabella-stop";

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: READ_MENU_ID,
    title: "Read selection with Isabella",
    contexts: ["selection"],
  });

  chrome.contextMenus.create({
    id: STOP_MENU_ID,
    title: "Stop Isabella",
    contexts: ["page", "selection"],
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (!tab?.id) {
    return;
  }

  if (info.menuItemId === READ_MENU_ID) {
    const text = (info.selectionText ?? "").trim();

    if (!text) {
      return;
    }

    chrome.tabs.sendMessage(tab.id, {
      type: "ISABELLA_SPEAK",
      text,
    });
  }

  if (info.menuItemId === STOP_MENU_ID) {
    chrome.tabs.sendMessage(tab.id, {
      type: "ISABELLA_STOP",
    });
  }
});
