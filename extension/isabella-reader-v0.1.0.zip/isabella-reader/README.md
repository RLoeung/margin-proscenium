# Isabella Local Reader

A small unpacked Vivaldi/Chromium extension that sends selected webpage text to
your local Kokoro server at `http://127.0.0.1:5150/speak`.

## Install in Vivaldi

1. Extract this folder somewhere permanent, such as:
   `C:\AI\kokoro\extension\isabella-reader`
2. Open `vivaldi://extensions`.
3. Enable **Developer mode**.
4. Click **Load unpacked**.
5. Select the extracted `isabella-reader` folder.

## Use

1. Start the Kokoro server:

   ```powershell
   cd C:\AI\kokoro
   .\.venv\Scripts\Activate.ps1
   python -m uvicorn scripts.server:app --host 127.0.0.1 --port 5150
   ```

2. Select text on a webpage.
3. Right-click the selection.
4. Choose **Read selection with Isabella**.
5. To stop playback, right-click the page and choose **Stop Isabella**.

## Notes

- Voice: `bf_isabella`
- Speed: `1.0`
- The extension sends text only to your local server.
- Browser-internal pages such as `vivaldi://extensions` do not permit ordinary
  extension content scripts.
