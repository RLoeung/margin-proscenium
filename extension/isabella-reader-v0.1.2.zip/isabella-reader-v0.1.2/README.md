# Isabella Local Reader v0.1.2

This revision moves the localhost request into the extension service worker.

Why: an HTTPS webpage may block a content script from fetching an HTTP
localhost endpoint as mixed or private-network content. The extension service
worker has explicit host permission for `127.0.0.1:5150`, so it performs the
request and passes the resulting WAV back to the page for playback.

## Update

1. Extract over the existing extension folder.
2. Open `vivaldi://extensions`.
3. Click the circular Reload button for Isabella Local Reader.
4. Refresh the webpage you are testing.
5. Select text, right-click, and choose **Read selection with Isabella**.
