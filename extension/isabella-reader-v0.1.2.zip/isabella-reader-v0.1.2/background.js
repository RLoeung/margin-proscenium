const READ_MENU_ID = "isabella-read-selection";
const STOP_MENU_ID = "isabella-stop";
const TTS_ENDPOINT = "http://127.0.0.1:5150/speak";
const DEFAULT_VOICE = "bf_isabella";
const DEFAULT_SPEED = 1.0;

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: READ_MENU_ID,
      title: "Read selection with Isabella",
      contexts: ["selection"],
    });

    chrome.contextMenus.create({
      id: STOP_MENU_ID,
      title: "Stop Isabella",
      contexts: ["page", "selection"],
    });
  });
});

async function injectReader(tabId) {
  await chrome.scripting.executeScript({
    target: { tabId },
    files: ["reader.js"],
  });
}

function arrayBufferToBase64(buffer) {
  const bytes = new Uint8Array(buffer);
  const chunkSize = 0x8000;
  let binary = "";

  for (let offset = 0; offset < bytes.length; offset += chunkSize) {
    const chunk = bytes.subarray(offset, offset + chunkSize);
    binary += String.fromCharCode(...chunk);
  }

  return btoa(binary);
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type !== "ISABELLA_FETCH_AUDIO") {
    return false;
  }

  (async () => {
    try {
      const response = await fetch(TTS_ENDPOINT, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          text: message.text,
          voice: DEFAULT_VOICE,
          speed: DEFAULT_SPEED,
        }),
      });

      if (!response.ok) {
        const details = await response.text();
        throw new Error(`Kokoro returned ${response.status}: ${details}`);
      }

      const audioBuffer = await response.arrayBuffer();

      sendResponse({
        ok: true,
        audioBase64: arrayBufferToBase64(audioBuffer),
        mimeType: response.headers.get("content-type") || "audio/wav",
      });
    } catch (error) {
      console.error("Isabella Local Reader:", error);
      sendResponse({
        ok: false,
        error: error?.message || String(error),
      });
    }
  })();

  return true;
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (!tab?.id) {
    return;
  }

  try {
    await injectReader(tab.id);

    if (info.menuItemId === READ_MENU_ID) {
      const text = (info.selectionText ?? "").trim();

      if (!text) {
        return;
      }

      await chrome.tabs.sendMessage(tab.id, {
        type: "ISABELLA_SPEAK",
        text,
      });
    }

    if (info.menuItemId === STOP_MENU_ID) {
      await chrome.tabs.sendMessage(tab.id, {
        type: "ISABELLA_STOP",
      });
    }
  } catch (error) {
    console.error("Isabella Local Reader:", error);
  }
});
