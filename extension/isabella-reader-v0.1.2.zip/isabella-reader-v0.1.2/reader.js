(() => {
  if (window.__isabellaReaderInstalled) {
    return;
  }

  window.__isabellaReaderInstalled = true;

  let currentAudio = null;
  let currentObjectUrl = null;
  let requestSerial = 0;

  function cleanUpPlayback() {
    if (currentAudio) {
      currentAudio.pause();
      currentAudio.src = "";
      currentAudio = null;
    }

    if (currentObjectUrl) {
      URL.revokeObjectURL(currentObjectUrl);
      currentObjectUrl = null;
    }
  }

  function stopSpeech() {
    requestSerial += 1;
    cleanUpPlayback();
  }

  function base64ToBlob(base64, mimeType) {
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);

    for (let index = 0; index < binary.length; index += 1) {
      bytes[index] = binary.charCodeAt(index);
    }

    return new Blob([bytes], { type: mimeType });
  }

  async function speak(text) {
    stopSpeech();
    const thisRequest = requestSerial;

    try {
      const result = await chrome.runtime.sendMessage({
        type: "ISABELLA_FETCH_AUDIO",
        text,
      });

      if (thisRequest !== requestSerial) {
        return;
      }

      if (!result?.ok) {
        throw new Error(result?.error || "The local TTS request failed.");
      }

      const audioBlob = base64ToBlob(
        result.audioBase64,
        result.mimeType || "audio/wav"
      );

      currentObjectUrl = URL.createObjectURL(audioBlob);
      currentAudio = new Audio(currentObjectUrl);

      currentAudio.addEventListener("ended", cleanUpPlayback, { once: true });
      currentAudio.addEventListener("error", cleanUpPlayback, { once: true });

      await currentAudio.play();
    } catch (error) {
      console.error("Isabella Local Reader:", error);
      alert(
        "Isabella could not speak. Make sure the Kokoro server is running at " +
        "http://127.0.0.1:5150."
      );
    }
  }

  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === "ISABELLA_SPEAK") {
      speak(message.text);
    }

    if (message.type === "ISABELLA_STOP") {
      stopSpeech();
    }
  });
})();
