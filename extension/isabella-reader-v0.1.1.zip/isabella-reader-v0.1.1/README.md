# Isabella Local Reader v0.1.1

This revision injects the reader only when the context-menu command is used.
That avoids "Receiving end does not exist" errors on tabs opened before the
extension was installed or reloaded.

## Update in Vivaldi

1. Extract this archive over your existing extension folder, or into a new one.
2. Open `vivaldi://extensions`.
3. Find Isabella Local Reader.
4. Click the circular **Reload** button.
5. Test on an ordinary webpage.

Internal pages such as `vivaldi://extensions` and some browser extension-store
pages do not permit script injection.
