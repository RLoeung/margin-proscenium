const READ_MENU_ID = "isabella-read-selection";
const STOP_MENU_ID = "isabella-stop";

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: READ_MENU_ID,
      title: "Read selection with Isabella",
      contexts: ["selection"],
    });

    chrome.contextMenus.create({
      id: STOP_MENU_ID,
      title: "Stop Isabella",
      contexts: ["page", "selection"],
    });
  });
});

async function injectReader(tabId) {
  await chrome.scripting.executeScript({
    target: { tabId },
    files: ["reader.js"],
  });
}

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (!tab?.id) {
    return;
  }

  try {
    await injectReader(tab.id);

    if (info.menuItemId === READ_MENU_ID) {
      const text = (info.selectionText ?? "").trim();

      if (!text) {
        return;
      }

      await chrome.tabs.sendMessage(tab.id, {
        type: "ISABELLA_SPEAK",
        text,
      });
    }

    if (info.menuItemId === STOP_MENU_ID) {
      await chrome.tabs.sendMessage(tab.id, {
        type: "ISABELLA_STOP",
      });
    }
  } catch (error) {
    console.error("Isabella Local Reader:", error);

    // Internal browser pages and some extension stores block script injection.
    if (
      error?.message?.includes("Cannot access") ||
      error?.message?.includes("The extensions gallery cannot be scripted")
    ) {
      console.warn(
        "This page does not allow extension scripts. Try an ordinary webpage."
      );
    }
  }
});
